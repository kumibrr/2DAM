import Ejercicio1
import Ejercicio2
import Ejercicio3
import Ejercicio4
import Ejercicio5

#Ejercicio1.Ejercicio1()
#Ejercicio2.Ejercicio2()
#Ejercicio3.Ejercicio3()
#Ejercicio4.Ejercicio4()
Ejercicio5.Ejercicio5()