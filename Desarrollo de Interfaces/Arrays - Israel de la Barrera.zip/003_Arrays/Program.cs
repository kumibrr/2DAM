﻿using System;

namespace _003_Arrays
{
    class Program
    {
        public static  int[] arr = new int[5];
        static void Main(string[] args)
        {
            
            
            ejercicio1();    
        }

        static void ejercicio1() {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine($"Introduce el valor {i}");
                arr[i] = Int32.Parse(Console.ReadLine());
            }

            int greatest = arr[0];
            int smallest = arr[0];
            foreach (int n in arr) {
                if (n > greatest) {
                    greatest = n;
                }
                if (n < smallest) {
                    smallest = n;
                }
            }
            Console.WriteLine($"El valor mínimo es \" {smallest} \" y el máximo es \' {greatest} \'");
        }
    }
}
